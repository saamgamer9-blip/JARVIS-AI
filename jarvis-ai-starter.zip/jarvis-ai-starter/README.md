# JARVIS AI

JARVIS uses a Node.js server to call either Google Gemini or OpenAI. API keys stay on the server.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your own `OPENAI_API_KEY` and/or `GEMINI_API_KEY` to `.env`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Deploy
Deploy this project to a Node.js host (for example Render or Railway). Set `OPENAI_API_KEY` and `GEMINI_API_KEY` as private environment variables in the host dashboard. Do not commit `.env` to GitHub.

## Notes
- ChatGPT/OpenAI and Gemini API usage may incur separate charges.
- The browser voice input depends on SpeechRecognition support; speech output uses browser speech synthesis.
- This is a starter implementation, not an autonomous device-control system.
